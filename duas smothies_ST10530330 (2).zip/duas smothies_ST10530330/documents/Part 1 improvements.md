Part 1: Summary of Structural HTML Changes
To make the page look truly professional, a few modifications were made to the raw HTML. In web development, structure (HTML) and presentation (CSS) work hand in hand.

1. Fixing Invalid Text Tags
The Problem: In your original code, the steps paragraph used <br>1.Sign up for free </br>. <br> is a self-closing tag meant only for line breaks; it cannot have a closing </br> tag. This creates rendering bugs in modern browsers.

The Solution: The text was separated into a clean, structured container (.steps-container) with individual step cards (.step-card). This allows us to style each step as its own distinct element rather than a giant wall of text.

2. Upgrading the Navigation bar
The Problem: Hardcoded text pipes (|) were used to separate links (e.g., Home|). These are rigid and don't scale well on mobile screens.

The Solution: The pipes were removed. Instead, CSS is used to dynamically control the spacing between the links.

3. Document Head Optimization
Added <meta charset="UTF-8"> and a mobile-responsive viewport tag to ensure the page renders correctly on smartphones.

Linked the external sheet via <link rel="stylesheet" href="style.css">.

Part 2: Explanation of the CSS Architecture
The stylesheet is built using a modular approach, moving from global configurations to highly specific components.

1. Design Tokens (CSS Variables)
At the very top of the stylesheet, you will find the :root selector. This acts as a central control panel for the website's visual theme:

--primary-color (#ff4a7a) & --secondary-color (#2ec4b6): A vibrant "berry pink" and "mint green" palette chosen specifically to match a fresh, energetic smoothie brand.

--dark-neutral (#2b2d42): Instead of using harsh pure black (#000), a deep charcoal navy was selected. It reduces eye strain and looks highly premium.

--radius-lg, --shadow-md, etc.: Saved presets for rounded corners and soft drop shadows to ensure visual consistency across the page.

2. Base Reset (* and body)
CSS
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
Browsers (like Chrome, Safari, and Edge) have different default styles for margins and padding. This universal reset strips away those default inconsistencies, giving us a completely blank, predictable canvas to build on. box-sizing: border-box ensures that adding padding to an element doesn't accidentally make it wider than intended.

3. Header & Navigation Layout (Flexbox)
The header utilizes CSS Flexbox via display: flex and justify-content: space-between.

This automatically pushes your logo to the far left and your navigation links to the far right, perfectly balancing the screen space.

position: sticky; top: 0; locks the navigation bar to the top of the viewport when the user scrolls down, keeping the menu accessible at all times.

The hover state (nav a:hover) switches the link text color smoothly to the berry pink using transition, creating an interactive, tactile feel.

4. The Hero Elements (main)
The content is constrained to a max-width: 800px and centered on the screen using margin: 3rem auto. This prevents your text lines from stretching out too wide on large desktop monitors, which is a common cause of poor readability.

5. Micro-Interactions on the Call to Action (CTA)
The .signup-btn is designed to grab undivided attention:

It uses a bright background, large font, and bold weight.

The Interaction: When a user hovers over the button, transform: translateY(-2px) physically lifts the button up slightly, while the drop shadow intensifies. This mimics a real-world physical button being reactive to touch.

6. The Three-Step Reward Layout (CSS Grid)
By shifting from a single paragraph to a grid structure, the steps are arranged using a modern layout engine:

CSS
display: grid;
grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
This single line of CSS creates an entirely responsive layout without needing complex media queries.

On a desktop, the three steps will sit side-by-side in three equal columns.

On a mobile screen, if the space drops below 220px per card, the cards will automatically collapse and stack vertically on top of one another safely.

The top border of each card (border-top: 4px solid var(--secondary-color)) acts as a visual anchor, tying the mint-green brand color back into the informational section of the page.